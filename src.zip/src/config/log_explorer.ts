import type { TableColumn } from "../components/table";
import type { FilterConfig } from "../components/search_and_filter";
import type { LogEvent } from "../types/log";

export const logExplorerColumns: TableColumn<LogEvent>[] = [
  {
    key: "time",
    label: "Time",
  },
  {
    key: "event_uid",
    label: "Event ID",
  },
  {
    key: "device_name",
    label: "Device",
  },
  {
    key: "severity",
    label: "Severity",
  },
  {
    key: "activity_name",
    label: "Activity",
  },
  {
    key: "class_name",
    label: "Class",
  },
  {
    key: "vendor_name",
    label: "Vendor",
  },
  {
    key: "original_format",
    label: "Format",
  },
];

export const logExplorerFilters: FilterConfig[] = [
  {
    key: "time",
    label: "Time",
    options: [
      { label: "Last 15 minutes", value: "15m" },
      { label: "Last 1 hour", value: "1h" },
      { label: "Last 24 hours", value: "24h" },
    ],
  },
  {
    key: "device",
    label: "Device",
    options: [
      { label: "Firewall-01", value: "Firewall-01" },
      { label: "Web-Server-01", value: "Web-Server-01" },
      { label: "Router-02", value: "Router-02" },
    ],
  },
  {
    key: "severity",
    label: "Severity",
    options: [
      { label: "Informational", value: "Informational" },
      { label: "Low", value: "Low" },
      { label: "Medium", value: "Medium" },
      { label: "High", value: "High" },
      { label: "Critical", value: "Critical" },
      { label: "Fatal", value: "Fatal" },
    ],
  },
  {
    key: "activity",
    label: "Activity",
    options: [
      { label: "Logon", value: "Logon" },
      { label: "HTTP Request", value: "HTTP Request" },
      { label: "Traffic", value: "Traffic" },
    ],
  },
  {
    key: "className",
    label: "Class",
    options: [
      { label: "Authentication", value: "Authentication" },
      { label: "Network Activity", value: "Network Activity" },
    ],
  },
];