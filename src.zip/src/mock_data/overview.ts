import type { Overview as OverviewData } from "../types/overview";

export const mockOverview: OverviewData = {
  stats: {
    total_events: 12480,
    events_per_second: 248,
    active_sources: 24,
    parsing_errors: 37,
  },

  event_volume: [
    { label: "10:00", value: 1200 },
    { label: "11:00", value: 1800 },
    { label: "12:00", value: 1500 },
    { label: "13:00", value: 2400 },
    { label: "14:00", value: 2100 },
    { label: "15:00", value: 2800 },
  ],

  events_by_source: [
    { label: "Firewall", value: 4200 },
    { label: "Web Server", value: 3100 },
    { label: "Database", value: 2400 },
    { label: "Endpoint", value: 1800 },
    { label: "Network", value: 1200 },
  ],

  events_by_severity: [
    { label: "Critical", value: 320 },
    { label: "High", value: 840 },
    { label: "Medium", value: 2100 },
    { label: "Low", value: 4600 },
  ],
};

