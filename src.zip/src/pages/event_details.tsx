import Card from "../components/card";
import DetailGrid from "../components/detail_grid";
import type { LogEvent } from "../types/log";

interface EventDetailsProps {
  event: LogEvent;
}

function EventDetails({ event }: EventDetailsProps) {
  const overviewDetails = [
    { label: "Event ID", value: event.event_uid },
    { label: "Time", value: event.time },
    { label: "Severity", value: event.severity },
    { label: "Message", value: event.message },
  ];

  const classificationDetails = [
    { label: "Category", value: event.category_name },
    { label: "Class", value: event.class_name },
    { label: "Activity", value: event.activity_name },
  ];

  const sourceDetails = [
    { label: "Device", value: event.device_name },
    { label: "Vendor", value: event.vendor_name },
    { label: "Product", value: event.product_name },
    { label: "Original Format", value: event.original_format },
  ];

  return (
    <div className="event-details">
      <Card title="Event Overview">
        <DetailGrid items={overviewDetails} />
      </Card>

      <Card title="Event Classification">
        <DetailGrid items={classificationDetails} />
      </Card>

      <Card title="Source Information">
        <DetailGrid items={sourceDetails} />
      </Card>

      <Card title="Raw Event">
        <pre className="raw-event">
          {event.raw_event}
        </pre>
      </Card>
    </div>
  );
}

export default EventDetails;