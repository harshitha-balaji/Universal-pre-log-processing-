import { useEffect, useState } from "react";
import Card from "../components/card";
import LineGraph from "../components/line_graph";
import HorizontalBarGraph from "../components/horizontal_bar_graph";
import { getOverview } from "../api/overview";
import type { Overview as OverviewData } from "../types/overview";

function Overview() {
    const [overviewData, setOverviewData] =
      useState<OverviewData | null>(null);

    useEffect(() => {
      const loadOverview = async () => {
        const data = await getOverview();
        setOverviewData(data);
      };

      loadOverview();
    }, []);

    if (!overviewData) {
      return null;
    } 
    const { stats } = overviewData; 
  return (
    <div className="overview-page">

      <div className="overview-metrics">

        <Card title="Total Events">
          <div className="metric-value">
            {stats.total_events.toLocaleString()}
          </div>
        </Card>

        <Card title="Events/sec">
          <div className="metric-value">
            {stats.events_per_second.toLocaleString()}
          </div>
        </Card>

        <Card title="Active Sources">
          <div className="metric-value">
            {stats.active_sources.toLocaleString()}
          </div>
        </Card>

        <Card title="Parsing Errors">
          <div className="metric-value">
            {stats.parsing_errors.toLocaleString()}
          </div>
        </Card>

      </div>

      <div className="overview-section">

        <Card title="Event Volume Over Time">
          <LineGraph
            data={overviewData.event_volume}
          />
        </Card>

      </div>

      <div className="overview-charts">

        <Card title="Events by Source">
          <HorizontalBarGraph
            data={overviewData.events_by_source}
          />
        </Card>

        <Card title="Events by Severity">
          <HorizontalBarGraph
            data={overviewData.events_by_severity}
          />
        </Card>

      </div>

    </div>
  );
}

export default Overview;