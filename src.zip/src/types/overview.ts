export interface OverviewStats {
  total_events: number;
  events_per_second: number;
  active_sources: number;
  parsing_errors: number;
}

export interface OverviewDataPoint {
  label: string;
  value: number;
}

export interface Overview {
  stats: OverviewStats;
  event_volume: OverviewDataPoint[];
  events_by_source: OverviewDataPoint[];
  events_by_severity: OverviewDataPoint[];
}