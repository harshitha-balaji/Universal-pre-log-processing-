export interface LogEvent {
  event_uid: string;
  time: string;
  category_name: string;
  class_name: string;
  activity_name: string;
  severity: "Informational" | "Low" | "Medium" | "High" | "Critical" | "Fatal";
  message: string;
  device_name: string;
  vendor_name: string;
  product_name: string;
  original_format: string;
  raw_event: string;
}

export interface SearchFilters {
  search: string;
  time: string;
  device: string;
  severity: string;
  activity: string;
  className: string;
}