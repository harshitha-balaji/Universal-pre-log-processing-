import type { Overview as OverviewData } from "../types/overview";
import { mockOverview } from "../mock_data/overview";

export async function getOverview(): Promise<OverviewData> {
  return Promise.resolve(mockOverview);
}