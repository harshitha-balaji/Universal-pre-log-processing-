import type { LogEvent, SearchFilters } from "../types/log";
import { mockLogs } from "../mock_data/logs";

export async function getLogs(
  filters: SearchFilters
): Promise<LogEvent[]> {
  const filteredLogs = mockLogs.filter((log) => {
    const searchMatch =
      filters.search === "" ||
      Object.values(log).some((value) =>
        String(value)
          .toLowerCase()
          .includes(filters.search.toLowerCase())
      );

    const deviceMatch =
      !filters.device ||
      log.device_name === filters.device;

    const severityMatch =
      !filters.severity ||
      log.severity === filters.severity;

    const activityMatch =
      !filters.activity ||
      log.activity_name === filters.activity;

    const classMatch =
      !filters.className ||
      log.class_name === filters.className;

    // Time filtering will be connected
    // once log.time becomes a real timestamp.
    const timeMatch = true;

    return (
      searchMatch &&
      timeMatch &&
      deviceMatch &&
      severityMatch &&
      activityMatch &&
      classMatch
    );
  });

  return Promise.resolve(filteredLogs);
}

